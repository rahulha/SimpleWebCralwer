﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
//using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCollector_Spider
{
    public partial class frmConsol : Form
    {
        public frmConsol()
        {
            InitializeComponent();
        }

        private void frmConsol_Load(object sender, EventArgs e)
        {

            if (String.IsNullOrEmpty(Properties.Settings.Default.IndexPath))
                txtBWSIdx.Text = Properties.Settings.Default.IndexPath;
            else
                btnBWSIndexFolder.PerformClick();

            if (String.IsNullOrEmpty(Properties.Settings.Default.IndexPathDiscarded))
                txtBWSIdxDiscarded.Text = Properties.Settings.Default.IndexPathDiscarded;
            else
                btnBWSIdxDiscarded.PerformClick();

            if (String.IsNullOrEmpty(Properties.Settings.Default.ThreadSleepTime))
                txtCWSleepTime.Text = Properties.Settings.Default.ThreadSleepTime;
            else
                btnCWSleepTime.PerformClick();

            CrawlerManager.CheckForRecovery();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (CheckAllPaths())
            {
                int cID = CrawlerManager.AddCrawler(txtBWSStorageFolder.Text);

                ListViewItem itm = new ListViewItem(cID.ToString());
                itm.SubItems.Add((txtCWName.Text == "") ? "Crawler " + cID.ToString() : txtCWName.Text);
                itm.SubItems.Add("Created");
                itm.SubItems.Add("Not running");
                itm.Tag = true;

                lsvCrawlerTheradList.Items.Add(itm);
            }
            else
                MessageBox.Show("Please select all locations first.", "Location Error - Control Panel", MessageBoxButtons.OK);
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in lsvCrawlerTheradList.SelectedItems)
            {
                try
                {
                    CrawlerManager.StartCrawler(Convert.ToInt32(itm.Text));
                    itm.SubItems[2].Text = "Running";
                }
                catch (Exception ex)
                {
                    // handle and log error
                    itm.SubItems[2].Text = "Error Running crawler, check log for details";
                }
            }
        }

        //private void btnPause_Click(object sender, EventArgs e)
        //{
        //    foreach (ListViewItem itm in lsvCrawlerTheradList.SelectedItems)
        //    {
        //        try
        //        {
        //            CrawlerManager.PauseCrawler(Convert.ToInt32(itm.Text));
        //            itm.SubItems[2].Text = "Paused";
        //        }
        //        catch (Exception ex)
        //        {
        //            // handle and log error
        //            itm.SubItems[2].Text = "Error Pasuing crawler, check log for details";
        //        }
        //    }
        //}

        //private void btnResume_Click(object sender, EventArgs e)
        //{
        //    foreach (ListViewItem itm in lsvCrawlerTheradList.SelectedItems)
        //    {
        //        try
        //        {
        //            CrawlerManager.ResumeCrawler(Convert.ToInt32(itm.Text));
        //            itm.SubItems[2].Text = "Running";
        //        }
        //        catch (Exception ex)
        //        {
        //            // handle and log error
        //            itm.SubItems[2].Text = "Error Resuming crawler, check log for details";
        //        }
        //    }
        //}

        private void btnStop_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in lsvCrawlerTheradList.SelectedItems)
            {
                try
                {
                    CrawlerManager.StopCrawler(Convert.ToInt32(itm.Text), "Stopped by User");
                    itm.SubItems[2].Text = "Stopped";
                }
                catch (Exception ex)
                {
                    // handle and log error
                    itm.SubItems[2].Text = "Error Stopping crawler, check log for details";
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in lsvCrawlerTheradList.SelectedItems)
            {
                try
                {
                    CrawlerManager.RemoveCrawler(Convert.ToInt32(itm.Text));
                    itm.SubItems[2].Text = "Removed. hit refresh to refresh the crawler list";
                    itm.Tag = false;
                }
                catch (Exception ex)
                {
                    // handle and log error
                    itm.SubItems[2].Text = "Error Stopping crawler, check log for details";
                }
            }
        }

        private void cmsCrawlerList_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            int Count = lsvCrawlerTheradList.Items.Count;

            for (int i = 0; i < Count; i++)
            {
                ListViewItem itm = lsvCrawlerTheradList.Items[i];
                if (Convert.ToBoolean(itm.Tag) == false)
                {
                    lsvCrawlerTheradList.Items.Remove(itm);
                    Count--;
                    i--;
                }
            }
        }



        private Boolean CheckAllPaths()
        {
            Boolean res = true;

            res = (txtBWSIdx.Text != "") & (txtBWSIdxDiscarded.Text != "") & (txtBWSStorageFolder.Text != "");

            return res;
        }



        private void btnBWSIndexFolder_Click(object sender, EventArgs e)
        {
            if (fbdIndexFolder.ShowDialog() == DialogResult.OK)
            {
                txtBWSIdx.Text = fbdIndexFolder.SelectedPath;
                Properties.Settings.Default.IndexPath = txtBWSIdx.Text;
                CrawlerManager.SetDefaultURLListPath(Properties.Settings.Default.IndexPath);
            }
        }

        private void btnBWSIdxDiscarded_Click(object sender, EventArgs e)
        {
            if (fbdIdxDiscarded.ShowDialog() == DialogResult.OK)
            {
                txtBWSIdxDiscarded.Text = fbdIdxDiscarded.SelectedPath;
                Properties.Settings.Default.IndexPathDiscarded = txtBWSIdxDiscarded.Text;
                CrawlerManager.SetDefaultDiscardedURLListPath(Properties.Settings.Default.IndexPathDiscarded);
            }
        }

        private void btnBWSStorage_Click(object sender, EventArgs e)
        {
            if (fbdStorage.ShowDialog() == DialogResult.OK)
            {
                txtBWSStorageFolder.Text = fbdStorage.SelectedPath;
                Properties.Settings.Default.StoragePath = txtBWSStorageFolder.Text;
            }
        }

        private void btnCWSleepTime_Click(object sender, EventArgs e)
        {
            if (txtCWSleepTime.Text != "")
            {
                Properties.Settings.Default.ThreadSleepTime = txtCWSleepTime.Text;
                CrawlerManager.SetMaxURLinFile(Convert.ToInt32(txtCWSleepTime.Text));
            }
            else
            {
                txtCWSleepTime.Text = "0";
                Properties.Settings.Default.ThreadSleepTime = "0";
            }
                
        }

        private void frmConsol_FormClosing(object sender, FormClosingEventArgs e)
        {
            CrawlerManager.Exit();
        }
    }
}
