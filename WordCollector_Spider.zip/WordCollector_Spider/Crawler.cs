﻿using HtmlAgilityPack;
using System;
using System.Linq;
using System.Threading;

namespace WordCollector_Spider
{

    class Crawler : IDisposable
    {
        private Thread ThPageReader;
        private String RootDirectoryLocation;
        private Boolean StopIndicator = false;
        public int ThreadSleepTime
        {
            get;
            set;
        }

        public int CrawlerID;

        private HtmlWeb web = new HtmlWeb();

        private LocationAddressManager NA = new LocationAddressManager();
        private StorageManager SMRef = new StorageManager();


        public Crawler(String ParentLocation)
        {
            this.RootDirectoryLocation = ParentLocation;
            this.ThreadSleepTime = 100;
        }

        String[] item;
        String HTMLSaveSortedFilePath;

        private void StartCollecting()
        {
            while (!StopIndicator)
            {
                try
                {
                    item = (String[])CrawlerManager.Dequeue(CrawlerID);
                }
                catch
                {
                    //In case error in Deueueing, which means no URLs anymore, exit the WHILE loop
                    break;
                }

                item[0] = CorrectURL(item[0], item[3]);
                HTMLSaveSortedFilePath = NA.SortedFilePath(item[0]);

                if (IsFileExist(item[0], RootDirectoryLocation))
                {
                    //Add try catch
                    //System.IO.File.WriteAllText(NA.GetHTMLFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), "");
                    HtmlAgilityPack.HtmlDocument doc = null;

                    try
                    {
                        doc = web.Load(item[0].ToString());
                    }
                    catch { }
                    if (doc != null)
                    {
                        if (doc.DocumentNode.ChildNodes.Count > 0)
                        {
                            SMRef.WriteFile(NA.GetHTMLFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), System.IO.FileMode.Append & System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, doc.DocumentNode.InnerHtml);

                             
                            String Links = "";

                            HtmlNodeCollection linkCol = doc.DocumentNode.SelectNodes("//a[@href]");
                            if (linkCol != null)
                            {
                                foreach (HtmlNode link in linkCol)
                                {
                                    try
                                    {
                                        if (ValidateURL(link.Attributes["href"].Value, item[0]))
                                        {

                                            Links = Links + "<Href><URL>" + link.Attributes["href"].Value + "</URL><DateStamp>" + DateTime.Today.Date.ToShortDateString() + "</DateStamp><TimeStamp>" + DateTime.Today.ToShortTimeString() + "</TimeStamp><RefBy>" + item[0].ToString() + "</RefBy></Href>" + Environment.NewLine;

                                            if (IsFileExist(CorrectURL(link.Attributes["href"].Value, item[0]), RootDirectoryLocation))
                                                CrawlerManager.Enqueue(link.Attributes["href"].Value, DateTime.Today.Date.ToShortDateString(), DateTime.Today.ToShortTimeString(), item[0].ToString());
                                        }
                                    }
                                    catch
                                    {
                                        //Log error, incorporate parameters: href, item[0], error code and error messages.
                                    }
                                }
                            }

                            SMRef.WriteFile(NA.GetRefFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), System.IO.FileMode.Append & System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, Links);
                        }
                        else
                        {
                            SMRef.CheckAndCreateFOlderStructure(RootDirectoryLocation, HTMLSaveSortedFilePath);
                            doc.Save(NA.GetHTMLFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath));
                        }
                    }
                    //SMRef.WriteFile(NA.GetRouteFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, "");
                    //SMRef.WriteFile(NA.GetRouteDifferenceFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, "");

                }
                else
                {
                    SMRef.WriteFile(NA.GetRefByFile(RootDirectoryLocation + "/" + HTMLSaveSortedFilePath), System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, item[3].ToString());
                }

                item = null;
                HTMLSaveSortedFilePath = null;

                Thread.Sleep(ThreadSleepTime);
            }
        }



        private Boolean IsFileExist(String CorrectedURLToCheck, String RootDirectory)
        {
            LocationAddressManager LA = new LocationAddressManager();

            if (CorrectedURLToCheck.Contains('?'))
            {
                String RootFileURL = CorrectedURLToCheck.Substring(0, CorrectedURLToCheck.LastIndexOf('?'));
                String RootURLFilePath = LA.SortedFilePath(RootFileURL);

                if (System.IO.File.Exists(LA.GetHTMLFile(RootDirectory + "/" + RootURLFilePath)))
                {

                    String RouteFile = (System.IO.File.Exists(NA.GetRouteFile(RootDirectory + "/" + RootURLFilePath))) ? System.IO.File.ReadAllText(NA.GetRouteFile(RootDirectory + "/" + RootURLFilePath)) : "";

                    //If root file is equal to the HTML retrieved from Querystring URL
                    if (RouteFile.Contains(CorrectedURLToCheck))
                    {
                        return false;
                    }
                    else
                    {
                        String RouteDiffFile = (System.IO.File.Exists(NA.GetRouteDifferenceFile(RootDirectory + "/" + RootURLFilePath))) ? System.IO.File.ReadAllText(NA.GetRouteDifferenceFile(RootDirectory + "/" + RootURLFilePath)) : "";

                        if (RouteDiffFile.Contains(CorrectedURLToCheck))
                        {
                            return false;
                        }
                        else
                        {
                            //Routing file dont contain this URL. Download it and then compare
                            String ComapreFile = System.IO.File.ReadAllText(NA.GetHTMLFile(RootDirectory + "/" + RootURLFilePath));
                            HtmlAgilityPack.HtmlDocument doc = web.Load(CorrectedURLToCheck);

                            //download the Querystring URL HTML content
                            //Use XMLDiff
                            if (CompareFIles(ComapreFile, doc.DocumentNode.InnerText))
                            {
                                SMRef.WriteFile(NA.GetRouteFile(RootDirectory + "/" + RootURLFilePath), System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, CorrectedURLToCheck + Environment.NewLine);
                                return false;
                            }
                            else
                            {
                                SMRef.WriteFile(NA.GetRouteDifferenceFile(RootDirectory + "/" + RootURLFilePath), System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite, CorrectedURLToCheck + Environment.NewLine);

                                string RootHTMLFIleSortedPath = NA.SortedFilePath(CorrectedURLToCheck);
                                return SMRef.DoesFileDontExist(RootDirectory, RootHTMLFIleSortedPath);
                            }
                        }
                    }
                }
                else
                {
                    CrawlerManager.Enqueue(CorrectedURLToCheck, item[1], item[2], item[3]);
                    item[0] = RootFileURL;
                    HTMLSaveSortedFilePath = RootURLFilePath;
                    return true;
                }
            }
            else
            {
                //Compare exiting file with new link

                string RootHTMLFIleSortedPath = NA.SortedFilePath(CorrectedURLToCheck);
                Boolean res;
            //if the Root file itself exist, create a new routing file 
            CheckBack: res = SMRef.DoesFileDontExist(RootDirectory, RootHTMLFIleSortedPath);
                Thread.Sleep(ThreadSleepTime);
                if (!System.IO.File.Exists(RootDirectory + "/" + RootHTMLFIleSortedPath + ".html"))
                    goto CheckBack;
                else
                    return res;
            }
        }

        private Boolean CompareFIles(String SourceFileText, String TargetFile)
        {
            SourceFileText = SourceFileText.Replace(@" ", @"");
            TargetFile = TargetFile.Replace(@" ", @"");

            if (SourceFileText.Contains(TargetFile) || SourceFileText.Equals(TargetFile))
                return true;
            else
                return false;
        }

        private Boolean ValidateURL(String StringURL, String ReferenceURI)
        {

            if (!StringURL.StartsWith("#") && StringURL != "" && StringURL != null && StringURL != string.Empty)
            {
                try
                {
                    Uri uri = new Uri(CorrectURL(StringURL, ReferenceURI));
                    if (uri.Scheme.Equals("javascript") || uri.Scheme.Equals("mailto"))
                        return false;
                    else
                        return true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
                return false;
        }

        private String CorrectURL(String StringURI, String ReferenceURI)
        {
            Uri uri1;

            if (!Uri.TryCreate(StringURI, UriKind.Absolute, out  uri1))
            {
                if (StringURI.StartsWith("/"))
                {
                    Uri refURI = new Uri(ReferenceURI);
                    StringURI = refURI.Scheme + "://" + refURI.Host + StringURI;
                }
                else if (StringURI.StartsWith("..") || StringURI.StartsWith("~"))
                {
                    ReferenceURI = ReferenceURI.Substring(0, ReferenceURI.LastIndexOf('/') - 1);
                    ReferenceURI = ReferenceURI.Substring(0, ReferenceURI.LastIndexOf('/') - 1);

                    StringURI = ReferenceURI + StringURI;
                }
                else if (StringURI.StartsWith("?"))
                {
                    StringURI = ReferenceURI + StringURI;
                }
                else
                {
                    StringURI = ReferenceURI + "/" + StringURI;
                }
            }
            return StringURI.TrimEnd(new char[] { '/' });
        }


        public void Start()
        {
            if (ThPageReader != null)
            {
                if ((ThPageReader.ThreadState == ThreadState.Suspended || ThPageReader.ThreadState == ThreadState.Stopped) && ThPageReader.ThreadState != ThreadState.Running)
                {
                    // start parsing thread
                    StopIndicator = false;
                    ThPageReader = new Thread(new ThreadStart(StartCollecting));
                    ThPageReader.Start();
                }
            }
            else
            {
                StopIndicator = false;
                ThPageReader = new Thread(new ThreadStart(StartCollecting));
                ThPageReader.Start();
            }
        }

        public Boolean Resume()
        {
            if (ThPageReader != null || ThPageReader.ThreadState == ThreadState.Suspended)
            {
                // Resume parsing thread
                //ThPageReader.Resume();
                StopIndicator = false;
                ThPageReader.Start();
                return true;
            }
            else
            {
                throw new Exception("Crawler not suspended or initialised");
            }
        }

        public Boolean Pause()
        {

            if (ThPageReader != null || ThPageReader.ThreadState == ThreadState.Running)
            {
                // Pause parsing thread
                StopIndicator = true;
                //ThPageReader.Suspend();
                return true;
            }
            else
            {
                throw new Exception("Crawler not running or initialised");
            }

        }

        public String Stop(String Message = "Stop signal sent to Crawler")
        {
            if (ThPageReader != null || ThPageReader.ThreadState == ThreadState.Running)
            {
                // Pause parsing thread
                StopIndicator = true;
                //ThPageReader.Abort();
                //ThPageReader = null;
                //while (ThPageReader.IsAlive)
                //    Thread.Sleep(50);

                return Message;
            }
            else
            {
                throw new Exception("Crawler not running or initialised");
            }

        }

        public void Dispose()
        {
            StopIndicator = false;

            ThPageReader.Abort();
            ThPageReader = null;

            RootDirectoryLocation = null;
            CrawlerID = 0;

            NA = null;

            SMRef = null;
        }
    }
}
