﻿using System;
using System.Linq;

namespace WordCollector_Spider
{
    public class StorageManager
    {
        public Boolean DoesFileDontExist(String ParentFolder, String FileLocation)
        {
            if (System.IO.File.Exists(ParentFolder + "/" + FileLocation + ".html"))
                return false;
            else
            {
                String[] FolderPaths = FileLocation.Split(new char[] { '/' });

                for (int i = 0; i < FolderPaths.Count() - 1; i++)
                {
                    if (!System.IO.Directory.Exists(ParentFolder + "/" + FolderPaths[i]))
                    {
                        System.IO.Directory.CreateDirectory(ParentFolder + "/" + FolderPaths[i]);
                        ParentFolder = ParentFolder + "/" + FolderPaths[i];
                    }
                    else
                        ParentFolder = ParentFolder + "/" + FolderPaths[i];
                }

                System.IO.File.WriteAllText(ParentFolder + "/" + FolderPaths[FolderPaths.Count() - 1] + ".html", " ");
                System.IO.File.WriteAllText(ParentFolder + "/" + FolderPaths[FolderPaths.Count() - 1] + ".rte", " ");
                System.IO.File.WriteAllText(ParentFolder + "/" + FolderPaths[FolderPaths.Count() - 1] + ".rtd", " ");


                FolderPaths = null;
                return true;
            }
        }

        public Boolean CheckAndCreateFOlderStructure(String ParentFolder, String FileLocation)
        {
            String[] FolderPaths = FileLocation.Split(new char[] { '/' });

            for (int i = 0; i < FolderPaths.Count() - 1; i++)
            {
                if (!System.IO.Directory.Exists(ParentFolder + "/" + FolderPaths[i]))
                {
                    System.IO.Directory.CreateDirectory(ParentFolder + "/" + FolderPaths[i]);
                    ParentFolder = ParentFolder + "/" + FolderPaths[i];
                }
                else
                    ParentFolder = ParentFolder + "/" + FolderPaths[i];
            }
            return true;
        }

        public void WriteFile(String File, System.IO.FileMode FileMode, System.IO.FileAccess FileAccess, System.IO.FileShare FileShare, String Text)
        {
            try
            {
                String[] FolderPaths = File.Split(new char[] { '/' });
                String ParentFolder = FolderPaths[0];

                for (int i = 1; i < FolderPaths.Count() - 1; i++)
                {
                    if (!System.IO.Directory.Exists(ParentFolder + "/" + FolderPaths[i]))
                    {
                        System.IO.Directory.CreateDirectory(ParentFolder + "/" + FolderPaths[i]);
                        ParentFolder = ParentFolder + "/" + FolderPaths[i];
                    }
                    else
                        ParentFolder = ParentFolder + "/" + FolderPaths[i];
                }

                System.IO.FileStream FS = new System.IO.FileStream(File, FileMode, FileAccess, FileShare);
                System.IO.StreamWriter SW = new System.IO.StreamWriter(FS);

                SW.Write(Text);
                SW.Flush();

                SW.Close();
                SW.Dispose();
                FS.Close();
                FS.Dispose();
                FS = null;
            }
            catch (Exception ex)
            {
                //Log error, include details: URL, Refby, date and time, error message, error code
                //throw ex;
            }
        }

    }
}
