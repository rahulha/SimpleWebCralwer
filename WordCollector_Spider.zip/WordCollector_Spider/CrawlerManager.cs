﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace WordCollector_Spider
{
    static class CrawlerManager
    {

        private static int MaxURLinFile
        {
            get;
            set;
        }
        private static String URLListPath
        {
            get;
            set;
        }
        private static String DiscaredURLListPath
        {
            get;
            set;
        }
        private static String CurrentEnqueueFileName
        {
            get;
            set;
        }
        private static String CurrentDequeueFileName
        {
            get;
            set;
        }

        static int NewFileQueCount = 0;

        static System.IO.FileStream FRS;
        static System.IO.StreamWriter SW;
        static Mutex muEnque = new Mutex();

        public static Queue qDGDBuffer = new Queue();
        static Mutex muDeque = new Mutex();

        public static List<Crawler> CrawlerList;
        public static int CrawlerCount = 0;

        static LocationAddressManager NA = new LocationAddressManager();
        static StorageManager sm = new StorageManager();


        //Set Default URL List/Index file folder. Also point to StreamWriters to that folder with new file.
        public static void SetDefaultURLListPath(String DefaultURLListPath)
        {
            URLListPath = NA.CorrectFIlePathInCFormat(DefaultURLListPath);

            CurrentEnqueueFileName = GetNewFileName(URLListPath);

            if (FRS != null)
            {
                SW.Flush();
                SW.Close();
                FRS.Close();
                FRS.Dispose();
                FRS = null;
            }

            FRS = new System.IO.FileStream(CurrentEnqueueFileName, System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.None);
            SW = new System.IO.StreamWriter(FRS);
            NewFileQueCount = 0;
        }

        //Set location for Discarded/Read Index files
        public static void SetDefaultDiscardedURLListPath(String DefaultDiscardedURLListPath)
        {
            DiscaredURLListPath = NA.CorrectFIlePathInCFormat(DefaultDiscardedURLListPath);
        }

        public static void SetMaxURLinFile(int MaxURLinFile)
        {
            CrawlerManager.MaxURLinFile = MaxURLinFile;
        }

        static CrawlerManager()
        {
            CrawlerList = new List<Crawler>();
            SetMaxURLinFile(5000);
        }

        //This function enqueues the new URL with few details from Crawler and writes to the file of URL lists.
        public static void Enqueue(String URL, String DateStamp, String TimeStamp, String ReferedBy)
        {
            muEnque.WaitOne();

            //Enlist only MaxURLinFile number of URLs in File
        Repeat: if (NewFileQueCount < MaxURLinFile)
            {
                SW.WriteLine(URL + "<SEP>" + DateStamp + "<SEP>" + TimeStamp + "<SEP>" + ReferedBy);
                SW.Flush();
                NewFileQueCount++;
            }
            else
            {
                //If the next URL to enqueue excede the MaxURLinFile, then close the current file and create new file and start Enqueuing in that
                if (FRS != null)
                {
                    SW.Flush();
                    SW.Close();
                    FRS.Close();
                    FRS.Dispose();
                    FRS = null;
                }

                CurrentEnqueueFileName = GetNewFileName(URLListPath);

                FRS = new System.IO.FileStream(CurrentEnqueueFileName, System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.None);
                SW = new System.IO.StreamWriter(FRS);
                NewFileQueCount = 0;

                goto Repeat;
            }

            muEnque.ReleaseMutex();
        }

        //This function is used by Crawlers to dequeue the next URL for indexing
        public static object[] Dequeue(int CrawlerID)
        {
            object[] itm = null;

            try
            {
                muDeque.WaitOne();
            }
            catch (AbandonedMutexException ex)
            {
                muDeque.ReleaseMutex();
            }
            finally
            {
                muDeque.WaitOne();

            }

            if (qDGDBuffer.Count > 0)
                itm = (object[])qDGDBuffer.Dequeue();
            else
            {
                //Check if file is ready to read and enqueue all URLs in that file
                if (FillQueueFromFile(URLListPath, DiscaredURLListPath))
                {
                    itm = (object[])qDGDBuffer.Dequeue();
                    muDeque.ReleaseMutex();
                }
                else
                {
                    //If there is no URL to enqueue and thus nothing to dequeue, Stop the calling crawler with appropriate messgae
                    StopCrawler(CrawlerID, "Dequeue failed, no available URLs");
                    muDeque.ReleaseMutex();
                    throw new Exception("No items available to dequeue");
                }
            }

            return itm;
        }

        //This is function fills the queue with new URLs from the next readable URL list file
        private static Boolean FillQueueFromFile(String FilePath, String DiscardedFilePath)
        {
            String[] FileNames = System.IO.Directory.GetFiles(FilePath);
            System.IO.FileStream FRS;

            //Get files in URLList files folder
            for (int i = 0; i < FileNames.Count(); i++)
            {

                FileNames[i] = FileNames[i].Replace("\\", "/");

                //In this case, check whether the said file is in use by crawlermanager by following condition.
                if (FileNames[i].Equals(CurrentEnqueueFileName))//&& NewFileQueCount > 0
                {
                    //If there is any error is opening the above file, the file must be used by CrawlerManager to enqueue the new URLs.

                    //If the file is in CrawlerManager, release the file, create a new file to point by CrawlerManager Engueue activity and set for loop counter "i" to -1 and iterate the loop. So Next iteration will take same file again and this time the file will be ready to open
                    muEnque.WaitOne();

                    if (CrawlerManager.FRS != null)
                    {
                        CrawlerManager.SW.Flush();
                        CrawlerManager.SW.Close();
                        CrawlerManager.FRS.Close();
                        CrawlerManager.FRS.Dispose();
                        CrawlerManager.FRS = null;
                    }

                    CurrentEnqueueFileName = GetNewFileName(FilePath);

                    CrawlerManager.FRS = new System.IO.FileStream(CurrentEnqueueFileName, System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.None);
                    CrawlerManager.SW = new System.IO.StreamWriter(CrawlerManager.FRS);
                    NewFileQueCount = 0;

                    muEnque.ReleaseMutex();

                    i--;
                }
                else
                {
                    //Get next file name to read indexes from. If any error occures, means the file is in use which means the Crawlermanager is using the file to enqueue to URLs.
                    CurrentDequeueFileName = FileNames[i];

                    FRS = new System.IO.FileStream(FileNames[i], System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite, System.IO.FileShare.None);

                    //if file is not open by any other thread and is ready to read, open the file and proceed for enqueue and discarding file to avoid multiple reading
                    System.IO.StreamReader SR = new System.IO.StreamReader(FRS);

                    String FileContent = SR.ReadToEnd();

                    SR.Close();
                    SR.Dispose();
                    FRS.Close();
                    FRS.Dispose();
                    FRS = null;

                    //Move the index file from Reading folder to Read folder. If the File already exists in Read folder, which means the current reading folder is the preserved one from Last Crawler instance and no need to move it again.
                    if (!System.IO.File.Exists(DiscardedFilePath + "/" + NA.GetFileNameFromFullPath(FileNames[i])))
                        System.IO.File.Move(FileNames[i], DiscardedFilePath + "/" + NA.GetFileNameFromFullPath(FileNames[i]));


                    //Set the current file in dequeue mode in recovery file.
                    System.IO.File.WriteAllText(System.Windows.Forms.Application.StartupPath + "/Recovery.config", DiscardedFilePath + "/" + NA.GetFileNameFromFullPath(FileNames[i]));

                    String[] LineSeparator = { Environment.NewLine };
                    String[] inLineSeparator = { "<SEP>" };

                    String[] LineContent = FileContent.Split(LineSeparator, StringSplitOptions.RemoveEmptyEntries);

                    if (LineContent.Count() > 0)
                    {
                        for (int j = 0; j < LineContent.Count(); j++)
                            qDGDBuffer.Enqueue(LineContent[j].Split(inLineSeparator, StringSplitOptions.RemoveEmptyEntries));

                        //Once read all URLs from List File, exit the for loop by jumping to FileFound label
                        goto FileFound;
                    }
                }
            }
            //In case, no files are available to read, means no URLs any further to enqueue and thus return False so Cralwer Manager can close the crawlers.
            return false;

        FileFound: return true;

        }

        //This function creates a new file name for use. It is simple an increament of file names in sequence. Ex. the last file in folder is 9.txt, the new will be 10.txt, and so on.
        private static String GetNewFileName(String FilePath)
        {
            String[] FileNames = System.IO.Directory.GetFiles(FilePath);

            if (FileNames.Count() > 0)
            {
                Char[] S = new char[] { '.' };

                String File = FileNames[FileNames.Count() - 1].Replace("\\", "/");
                File = File.Substring(File.LastIndexOf('/') + 1);
                File = File.Substring(0, File.LastIndexOf('.'));

                String NewFileName = (Convert.ToInt32(File) + 1).ToString();

                while (NewFileName.Length <= 100)
                    NewFileName = "0" + NewFileName;

                return FilePath + "/" + NewFileName + ".txt";
            }
            else
                return FilePath + "/1.txt";
        }

        //Exit the entire Crawler. Close all Crawlers, preserver state of current queue and close it.
        public static Boolean Exit()
        {
            foreach (Crawler C in CrawlerList)
            {
                C.Stop();
                //CrawlerList[C.CrawlerID].Dispose();
                //CrawlerList[C.CrawlerID] = null;
            }

            CrawlerList.Clear();
            CrawlerList = null;
            CrawlerCount = 0;

            String strQueueStatus = "";

            try
            {
                muDeque.WaitOne();
            }
            catch (AbandonedMutexException ex)
            {
                muDeque.ReleaseMutex();
            }
            finally
            {
                muDeque.WaitOne();

            }

            while (qDGDBuffer.Count > 0)
            {
                String[] itm = (String[])qDGDBuffer.Dequeue();
                strQueueStatus = strQueueStatus + itm[0] + "<SEP>" + itm[1] + "<SEP>" + itm[2] + "<SEP>" + itm[3] + Environment.NewLine;
            }

            muDeque.ReleaseMutex();

            sm.WriteFile(CurrentDequeueFileName, System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None, strQueueStatus);

            MaxURLinFile = 0;
            URLListPath = null;
            DiscaredURLListPath = null;
            CurrentEnqueueFileName = null;
            NewFileQueCount = 0;

            try
            {
                muEnque.WaitOne();
            }
            catch (AbandonedMutexException ex)
            {
                muEnque.ReleaseMutex();
            }
            finally
            {
                muEnque.WaitOne();
            }

            SW.Flush();
            SW.Close();
            FRS.Close();
            SW.Dispose();
            FRS.Dispose();
            SW = null;
            FRS = null;

            muEnque.ReleaseMutex();
            muEnque.Close();
            muEnque.Dispose();
            muEnque = null;

            qDGDBuffer.Clear();
            qDGDBuffer = null;
            muDeque.Close();
            muDeque.Dispose();
            muDeque = null;

            System.IO.File.Delete(System.Windows.Forms.Application.StartupPath + "/Recovery.config");

            NA = null;
            sm = null;



            return true;
        }

        #region "Crawler manager"

        public static int AddCrawler(String TempStorageLocation)
        {
            Crawler CW = new Crawler(NA.CorrectFIlePathInCFormat(TempStorageLocation));
            CrawlerCount += 1;

            CW.CrawlerID = CrawlerCount;

            CrawlerList.Add(CW);

            return CrawlerCount;
        }

        public static int StartCrawler(int CrawlerID)
        {
            if (CrawlerID > 0 && CrawlerID <= CrawlerCount)
            {
                Crawler CW = CrawlerList[CrawlerID - 1];
                CW.Start();
                return CrawlerID;
            }
            else
            {
                throw new Exception("Crawler dont exist");
            }
        }

        public static Boolean ResumeCrawler(int CrawlerID)
        {
            if (CrawlerID > 0 && CrawlerID <= CrawlerCount)
            {
                Crawler CW = CrawlerList[CrawlerID - 1];
                CW.Resume();
                return true;
            }
            else
            {
                throw new Exception("Crawler dont exist");
            }
        }

        public static Boolean PauseCrawler(int CrawlerID)
        {

            if (CrawlerID > 0 && CrawlerID <= CrawlerCount)
            {
                return CrawlerList[CrawlerID - 1].Pause();
            }
            else
            {
                throw new Exception("Crawler dont exist");
            }
        }

        public static String StopCrawler(int CrawlerID, String Message)
        {
            if (CrawlerID > 0 && CrawlerID <= CrawlerCount && CrawlerList[CrawlerID - 1] != null)
            {
                return CrawlerList[CrawlerID - 1].Stop(Message);
            }
            else
            {
                throw new Exception("Crawler dont exist");
            }

        }

        public static Boolean RemoveCrawler(int CrawlerID)
        {

            if (CrawlerID > 0 && CrawlerID <= CrawlerCount)
            {
                CrawlerList[CrawlerID - 1].Dispose();
                CrawlerList[CrawlerID - 1] = null;

                return true;
            }
            else
            {
                throw new Exception("Crawler dont exist");
            }

        }

        public static void CheckForRecovery()
        {
            if (System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "/Recovery.config"))
            {
                //Recovery code
                try
                {
                    String FullFileNameToRecover = System.IO.File.ReadAllText(System.Windows.Forms.Application.StartupPath + "/Recovery.config").Trim();
                    String FileNameToRecover = NA.GetFileNameFromFullPath(FullFileNameToRecover);

                    System.IO.File.Move(FullFileNameToRecover, URLListPath + "/" + FileNameToRecover);
                }
                catch
                {

                }
            }
        }

        #endregion
    }
}
