﻿namespace WordCollector_Spider
{
    partial class frmConsol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lsvCrawlerTheradList = new System.Windows.Forms.ListView();
            this.cwID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cwName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cwStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cwURL = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.tcViewer = new System.Windows.Forms.TabControl();
            this.tpList = new System.Windows.Forms.TabPage();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblIndexFolder = new System.Windows.Forms.Label();
            this.txtBWSIdx = new System.Windows.Forms.TextBox();
            this.btnBWSIndexFolder = new System.Windows.Forms.Button();
            this.btnBWSIdxDiscarded = new System.Windows.Forms.Button();
            this.txtBWSIdxDiscarded = new System.Windows.Forms.TextBox();
            this.lblBWSIdxDiscarded = new System.Windows.Forms.Label();
            this.btnBWSStorage = new System.Windows.Forms.Button();
            this.txtBWSStorageFolder = new System.Windows.Forms.TextBox();
            this.lblBWSStorageFolder = new System.Windows.Forms.Label();
            this.txtCWName = new System.Windows.Forms.TextBox();
            this.lblCWName = new System.Windows.Forms.Label();
            this.fbdIndexFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.fbdIdxDiscarded = new System.Windows.Forms.FolderBrowserDialog();
            this.fbdStorage = new System.Windows.Forms.FolderBrowserDialog();
            this.HorizontalSeparator1 = new System.Windows.Forms.Label();
            this.cmsCrawlerList = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtCWSleepTime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCWSleepTime = new System.Windows.Forms.Button();
            this.tcViewer.SuspendLayout();
            this.tpList.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Location = new System.Drawing.Point(813, 146);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(154, 90);
            this.btnRun.TabIndex = 0;
            this.btnRun.Text = "Run Crawler";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // btnStop
            // 
            this.btnStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStop.Location = new System.Drawing.Point(813, 242);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(154, 90);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "Stop Cralwer";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lsvCrawlerTheradList
            // 
            this.lsvCrawlerTheradList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lsvCrawlerTheradList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cwID,
            this.cwName,
            this.cwStatus,
            this.cwURL});
            this.lsvCrawlerTheradList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvCrawlerTheradList.FullRowSelect = true;
            this.lsvCrawlerTheradList.GridLines = true;
            this.lsvCrawlerTheradList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lsvCrawlerTheradList.Location = new System.Drawing.Point(3, 3);
            this.lsvCrawlerTheradList.Name = "lsvCrawlerTheradList";
            this.lsvCrawlerTheradList.Size = new System.Drawing.Size(780, 286);
            this.lsvCrawlerTheradList.TabIndex = 4;
            this.lsvCrawlerTheradList.UseCompatibleStateImageBehavior = false;
            this.lsvCrawlerTheradList.View = System.Windows.Forms.View.Details;
            // 
            // cwID
            // 
            this.cwID.Text = "Crawler ID";
            this.cwID.Width = 75;
            // 
            // cwName
            // 
            this.cwName.Text = "Crawler Name";
            this.cwName.Width = 196;
            // 
            // cwStatus
            // 
            this.cwStatus.Text = "Crawler Status";
            this.cwStatus.Width = 163;
            // 
            // cwURL
            // 
            this.cwURL.Text = "Current URL";
            this.cwURL.Width = 321;
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.Location = new System.Drawing.Point(812, 50);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(155, 90);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Add Crawler";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemove.Location = new System.Drawing.Point(813, 338);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(154, 90);
            this.btnRemove.TabIndex = 6;
            this.btnRemove.Text = "Remove Crawler";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // tcViewer
            // 
            this.tcViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tcViewer.Controls.Add(this.tpList);
            this.tcViewer.Controls.Add(this.tpLog);
            this.tcViewer.Location = new System.Drawing.Point(13, 110);
            this.tcViewer.Name = "tcViewer";
            this.tcViewer.SelectedIndex = 0;
            this.tcViewer.Size = new System.Drawing.Size(794, 318);
            this.tcViewer.TabIndex = 7;
            // 
            // tpList
            // 
            this.tpList.Controls.Add(this.lsvCrawlerTheradList);
            this.tpList.Location = new System.Drawing.Point(4, 22);
            this.tpList.Name = "tpList";
            this.tpList.Padding = new System.Windows.Forms.Padding(3);
            this.tpList.Size = new System.Drawing.Size(786, 292);
            this.tpList.TabIndex = 0;
            this.tpList.Text = "Crawler List";
            this.tpList.UseVisualStyleBackColor = true;
            // 
            // tpLog
            // 
            this.tpLog.Controls.Add(this.richTextBox1);
            this.tpLog.Location = new System.Drawing.Point(4, 22);
            this.tpLog.Name = "tpLog";
            this.tpLog.Padding = new System.Windows.Forms.Padding(3);
            this.tpLog.Size = new System.Drawing.Size(786, 292);
            this.tpLog.TabIndex = 1;
            this.tpLog.Text = "Log";
            this.tpLog.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(3, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(780, 286);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // lblIndexFolder
            // 
            this.lblIndexFolder.AutoSize = true;
            this.lblIndexFolder.Location = new System.Drawing.Point(13, 13);
            this.lblIndexFolder.Name = "lblIndexFolder";
            this.lblIndexFolder.Size = new System.Drawing.Size(92, 13);
            this.lblIndexFolder.TabIndex = 8;
            this.lblIndexFolder.Text = "Index Files Folder:";
            // 
            // txtBWSIdx
            // 
            this.txtBWSIdx.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtBWSIdx.Location = new System.Drawing.Point(102, 14);
            this.txtBWSIdx.Name = "txtBWSIdx";
            this.txtBWSIdx.ReadOnly = true;
            this.txtBWSIdx.Size = new System.Drawing.Size(190, 20);
            this.txtBWSIdx.TabIndex = 9;
            // 
            // btnBWSIndexFolder
            // 
            this.btnBWSIndexFolder.Location = new System.Drawing.Point(298, 11);
            this.btnBWSIndexFolder.Name = "btnBWSIndexFolder";
            this.btnBWSIndexFolder.Size = new System.Drawing.Size(29, 23);
            this.btnBWSIndexFolder.TabIndex = 10;
            this.btnBWSIndexFolder.Text = "...";
            this.btnBWSIndexFolder.UseVisualStyleBackColor = true;
            this.btnBWSIndexFolder.Click += new System.EventHandler(this.btnBWSIndexFolder_Click);
            // 
            // btnBWSIdxDiscarded
            // 
            this.btnBWSIdxDiscarded.Location = new System.Drawing.Point(684, 14);
            this.btnBWSIdxDiscarded.Name = "btnBWSIdxDiscarded";
            this.btnBWSIdxDiscarded.Size = new System.Drawing.Size(29, 23);
            this.btnBWSIdxDiscarded.TabIndex = 13;
            this.btnBWSIdxDiscarded.Text = "...";
            this.btnBWSIdxDiscarded.UseVisualStyleBackColor = true;
            this.btnBWSIdxDiscarded.Click += new System.EventHandler(this.btnBWSIdxDiscarded_Click);
            // 
            // txtBWSIdxDiscarded
            // 
            this.txtBWSIdxDiscarded.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtBWSIdxDiscarded.Location = new System.Drawing.Point(482, 15);
            this.txtBWSIdxDiscarded.Name = "txtBWSIdxDiscarded";
            this.txtBWSIdxDiscarded.ReadOnly = true;
            this.txtBWSIdxDiscarded.Size = new System.Drawing.Size(196, 20);
            this.txtBWSIdxDiscarded.TabIndex = 12;
            // 
            // lblBWSIdxDiscarded
            // 
            this.lblBWSIdxDiscarded.AutoSize = true;
            this.lblBWSIdxDiscarded.Location = new System.Drawing.Point(333, 16);
            this.lblBWSIdxDiscarded.Name = "lblBWSIdxDiscarded";
            this.lblBWSIdxDiscarded.Size = new System.Drawing.Size(149, 13);
            this.lblBWSIdxDiscarded.TabIndex = 11;
            this.lblBWSIdxDiscarded.Text = "Index Files Folder (Discarded):";
            // 
            // btnBWSStorage
            // 
            this.btnBWSStorage.Location = new System.Drawing.Point(762, 57);
            this.btnBWSStorage.Name = "btnBWSStorage";
            this.btnBWSStorage.Size = new System.Drawing.Size(29, 23);
            this.btnBWSStorage.TabIndex = 16;
            this.btnBWSStorage.Text = "...";
            this.btnBWSStorage.UseVisualStyleBackColor = true;
            this.btnBWSStorage.Click += new System.EventHandler(this.btnBWSStorage_Click);
            // 
            // txtBWSStorageFolder
            // 
            this.txtBWSStorageFolder.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtBWSStorageFolder.Location = new System.Drawing.Point(106, 56);
            this.txtBWSStorageFolder.Name = "txtBWSStorageFolder";
            this.txtBWSStorageFolder.ReadOnly = true;
            this.txtBWSStorageFolder.Size = new System.Drawing.Size(650, 20);
            this.txtBWSStorageFolder.TabIndex = 15;
            // 
            // lblBWSStorageFolder
            // 
            this.lblBWSStorageFolder.AutoSize = true;
            this.lblBWSStorageFolder.Location = new System.Drawing.Point(17, 57);
            this.lblBWSStorageFolder.Name = "lblBWSStorageFolder";
            this.lblBWSStorageFolder.Size = new System.Drawing.Size(79, 13);
            this.lblBWSStorageFolder.TabIndex = 14;
            this.lblBWSStorageFolder.Text = "Storage Folder:";
            // 
            // txtCWName
            // 
            this.txtCWName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCWName.Location = new System.Drawing.Point(106, 84);
            this.txtCWName.Name = "txtCWName";
            this.txtCWName.Size = new System.Drawing.Size(685, 20);
            this.txtCWName.TabIndex = 18;
            // 
            // lblCWName
            // 
            this.lblCWName.AutoSize = true;
            this.lblCWName.Location = new System.Drawing.Point(17, 85);
            this.lblCWName.Name = "lblCWName";
            this.lblCWName.Size = new System.Drawing.Size(73, 13);
            this.lblCWName.TabIndex = 17;
            this.lblCWName.Text = "Crawler Name";
            // 
            // fbdIndexFolder
            // 
            this.fbdIndexFolder.Description = "The Folder path from where to pick-up URL files";
            // 
            // fbdIdxDiscarded
            // 
            this.fbdIdxDiscarded.Description = "The folder path to where URL list files are stored after read";
            // 
            // fbdStorage
            // 
            this.fbdStorage.Description = "Location to store indexed files";
            // 
            // HorizontalSeparator1
            // 
            this.HorizontalSeparator1.BackColor = System.Drawing.Color.Black;
            this.HorizontalSeparator1.Location = new System.Drawing.Point(13, 44);
            this.HorizontalSeparator1.Name = "HorizontalSeparator1";
            this.HorizontalSeparator1.Size = new System.Drawing.Size(954, 1);
            this.HorizontalSeparator1.TabIndex = 19;
            // 
            // cmsCrawlerList
            // 
            this.cmsCrawlerList.Name = "cmsCrawlerList";
            this.cmsCrawlerList.ShowImageMargin = false;
            this.cmsCrawlerList.Size = new System.Drawing.Size(128, 26);
            this.cmsCrawlerList.Text = "&Refresh List";
            this.cmsCrawlerList.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmsCrawlerList_ItemClicked);
            // 
            // txtCWSleepTime
            // 
            this.txtCWSleepTime.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCWSleepTime.Location = new System.Drawing.Point(844, 12);
            this.txtCWSleepTime.MaxLength = 10;
            this.txtCWSleepTime.Name = "txtCWSleepTime";
            this.txtCWSleepTime.Size = new System.Drawing.Size(80, 20);
            this.txtCWSleepTime.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(719, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Crawler Sleep time (ms):";
            // 
            // btnCWSleepTime
            // 
            this.btnCWSleepTime.Location = new System.Drawing.Point(927, 11);
            this.btnCWSleepTime.Name = "btnCWSleepTime";
            this.btnCWSleepTime.Size = new System.Drawing.Size(40, 23);
            this.btnCWSleepTime.TabIndex = 23;
            this.btnCWSleepTime.Text = "Save";
            this.btnCWSleepTime.UseVisualStyleBackColor = true;
            this.btnCWSleepTime.Click += new System.EventHandler(this.btnCWSleepTime_Click);
            // 
            // frmConsol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 437);
            this.Controls.Add(this.btnCWSleepTime);
            this.Controls.Add(this.txtCWSleepTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HorizontalSeparator1);
            this.Controls.Add(this.txtCWName);
            this.Controls.Add(this.lblCWName);
            this.Controls.Add(this.btnBWSStorage);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtBWSStorageFolder);
            this.Controls.Add(this.lblBWSStorageFolder);
            this.Controls.Add(this.btnBWSIdxDiscarded);
            this.Controls.Add(this.txtBWSIdxDiscarded);
            this.Controls.Add(this.lblBWSIdxDiscarded);
            this.Controls.Add(this.btnBWSIndexFolder);
            this.Controls.Add(this.txtBWSIdx);
            this.Controls.Add(this.lblIndexFolder);
            this.Controls.Add(this.tcViewer);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnRun);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmConsol";
            this.Text = "Crawler - Admin Consol";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmConsol_FormClosing);
            this.Load += new System.EventHandler(this.frmConsol_Load);
            this.tcViewer.ResumeLayout(false);
            this.tpList.ResumeLayout(false);
            this.tpLog.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.ListView lsvCrawlerTheradList;
        private System.Windows.Forms.ColumnHeader cwID;
        private System.Windows.Forms.ColumnHeader cwStatus;
        private System.Windows.Forms.ColumnHeader cwURL;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TabControl tcViewer;
        private System.Windows.Forms.TabPage tpList;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.Label lblIndexFolder;
        private System.Windows.Forms.TextBox txtBWSIdx;
        private System.Windows.Forms.Button btnBWSIndexFolder;
        private System.Windows.Forms.Button btnBWSIdxDiscarded;
        private System.Windows.Forms.TextBox txtBWSIdxDiscarded;
        private System.Windows.Forms.Label lblBWSIdxDiscarded;
        private System.Windows.Forms.Button btnBWSStorage;
        private System.Windows.Forms.TextBox txtBWSStorageFolder;
        private System.Windows.Forms.Label lblBWSStorageFolder;
        private System.Windows.Forms.TextBox txtCWName;
        private System.Windows.Forms.Label lblCWName;
        private System.Windows.Forms.ColumnHeader cwName;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.FolderBrowserDialog fbdIndexFolder;
        private System.Windows.Forms.FolderBrowserDialog fbdIdxDiscarded;
        private System.Windows.Forms.FolderBrowserDialog fbdStorage;
        private System.Windows.Forms.Label HorizontalSeparator1;
        private System.Windows.Forms.ContextMenuStrip cmsCrawlerList;
        private System.Windows.Forms.TextBox txtCWSleepTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCWSleepTime;
    }
}

