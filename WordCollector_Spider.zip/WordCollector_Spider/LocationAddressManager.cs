﻿using System;
using System.Linq;

namespace WordCollector_Spider
{
    public class LocationAddressManager
    {

        public String SortedFilePath(Uri URI)
        {

            String FilterAboslutePath = URI.AbsoluteUri.TrimEnd(new char[] { '/' }).Replace(':', '_').Replace('\\', '_').Replace('<', '_').Replace('>', '_').Replace('*', '_').Replace('?', '/').Replace('|', '_').Replace('"', '_').Replace("//", "/");

            return FilterAboslutePath;
        }

        public String SortedFilePath(String StringURI)
        {
            Uri objURI = new Uri(StringURI);

            return SortedFilePath(objURI);
        }

        public string PageNameTitle(String SortedFilePath)
        {
            return SortedFilePath.Substring(SortedFilePath.LastIndexOf("/") + 1);
        }

        public string GetRefFile(String SortedFilePath)
        {

            return SortedFilePath + ".ref";
        }

        public string GetRefByFile(String SortedFilePath)
        {

            return SortedFilePath + ".rby";
        }

        public string GetHTMLFile(String SortedFilePath)
        {

            return SortedFilePath + ".html";
        }

        public string GetRouteFile(String SortedFilePath)
        {
            return SortedFilePath + ".rte";
        }

        public string GetRouteDifferenceFile(String SortedFilePath)
        {
            return SortedFilePath + ".rtd";
        }

        public string GetFileNameFromFullPath(String FileNameWithPath)
        {

            FileNameWithPath = FileNameWithPath.Replace("\\", "/");

            char[] c = new char[] { '/' };
            String[] names = FileNameWithPath.Split(c);


            return names[names.Count() - 1];

        }

        public string CorrectFIlePathInCFormat(String Address)
        {
            return Address.Replace("\\", "/");
        }


    }
}
